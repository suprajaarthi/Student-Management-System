﻿using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Utils;
using StudentsProgressmanagement.AllDetails;
using StudentsProgressmanagement.ViewDetails;
using System;
using System.Data;
using System.Threading.Tasks;

namespace StudentsProgressmanagement.NavigationModule
{
    [ModuleServiceProvider(typeof(INavigationToModule))]
    public sealed class NavigationToModule : Module, INavigationToModule
    {
        #region Module Dependency
        /// <summary>
        ///Teacher Registration Module Dependency
        /// </summary>
        [ModuleDependency]
        private readonly INewTeacherRegistration newTeacherRegistration = null;

       
        //[ModuleDependency]
        //private readonly ITeacherLogin teacherLogin = null;


      
        #endregion


        #region constructor 
        /// <summary>
        /// constructor
        /// </summary>
        public NavigationToModule() : base(typeof(NavigationToModule).Name) { }
        #endregion

        public async Task NavigationMethodAsync()
        {
            ExtendedConsole.WriteLine(ConsoleColor.Yellow, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.Yellow, "                                                        /-/-/-/        Student Management System         /-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.Yellow, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            Console.WriteLine("");
            Console.Clear();
            TitleDescription();
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "1. New User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "2. Existing User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "3. Contact us");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "4. Exit Application");
            Console.WriteLine();
            Console.Write("Enter any option from 1 to 4 : ");
            MainMenuDescription();
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option .... Please type a correct option ");
                value = Console.ReadLine();
            }
            
            switch (option)
            {
                case 1: await RegistrationPageAsync(); break;
                //case 2: await LoginPageAsync(); break;
                //case 3: await CustomerSupportDetails(); break;
                //case 4: await QuitAppAsync(); break;
                //default: await MainMenuExceptionAsync(); break;
            }
        }
        private void MainMenuDescription()
        {
            Console.Clear();
            TitleDescription();
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "1. New User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "2. Existing User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "3. Contact us");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "4. Exit Application");
            Console.WriteLine();
            Console.Write("Enter any option from 1 to 4 : ");
        }
        private void TitleDescription()
        {
            ExtendedConsole.WriteLine(ConsoleColor.Yellow, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.Yellow, "                                                        /-/-/-/        Student Management System         /-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.Yellow, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            Console.WriteLine("");
        }

        /// <summary>
        /// New user registration module
        /// </summary>
        private async Task RegistrationPageAsync()
        {
            Console.Clear();
            TitleDescription();
            //RegistrationDescription();
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option !.. Please Enter a Valid Number : ");
                value = Console.ReadLine();
            }
            Console.WriteLine();
            switch (option)
            {
                case 1: await AddNewTeacherDetails(); break;
                //case 2: await AddNewStudentDetails(); break;
                case 3: await NavigationMethodAsync(); break;
                default:
                    Console.WriteLine("Invaild Option..");
                    Console.WriteLine("Please Enter the correct option.. Press Enter to Continue again. ");
                    Console.ReadLine();
                    await RegistrationPageAsync();
                    break;
            }
        }

        /// <summary>
        /// <see cref="INavigationToModule.AddNewTeacherDetails()"/>
        /// </summary>
        public async Task AddNewTeacherDetails()
        {
            TeacherDetails teacherDetails = new TeacherDetails();
            Console.Write("Enter the Teacher's Name            : ");
            teacherDetails.TeacherName = Console.ReadLine();
            //await viewSpecialities.ViewSpecialityDetailsAsync();
            Console.Write("Enter Teacher's Department ID        : ");
            teacherDetails.DepartmentID = Int32.Parse(Console.ReadLine());
            Console.Write("Enter Teacher's Qualification        : ");
            teacherDetails.TeacherQualification = Console.ReadLine();
            Console.Write("Enter Teacher's Experience           : ");
            teacherDetails.TeacherExperience = float.Parse(Console.ReadLine());
            Console.Write("Enter the Teacher's Contact Number  : ");
            teacherDetails.TeacherContactNumber = Int32.Parse(Console.ReadLine());
            Console.Write("Enter the Teacher's Mail ID         : ");
            teacherDetails.TeacherMailID = Console.ReadLine();
            Console.Write("Enter Teacher  password              : ");
            // Implement later 
            //teacherDetails.TeacherPassword = ReadPassword();

            await newTeacherRegistration.AddNewTeacherAsync(teacherDetails);
            Console.WriteLine(teacherDetails.TeacherName + " Added Sucessfully!!!!! ");
            Console.WriteLine("Press Any key to go back to Main menu");
            Console.ReadKey();
            await NavigationMethodAsync();
        }

       
    }
}