﻿using System;
using System.Threading.Tasks;

namespace StudentsProgressmanagement.NavigationModule
{
    public interface INavigationToModule
    {
        Task AddNewTeacherDetails();
        Task NavigationMethodAsync();
    }
}
