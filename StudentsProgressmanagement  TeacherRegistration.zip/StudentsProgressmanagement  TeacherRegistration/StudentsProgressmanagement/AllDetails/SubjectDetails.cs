using System;
namespace StudentsProgressmanagement.AllDetails
{
    public class SubjectDetails
    {
        #region  Constructor 
        public SubjectDetails()
        {

        }
        #endregion

        #region Public Properties 

        public Int32 SubjectID{get;set;}

        public String SubjectName{get;set;}

        public Int32 DepartmentID{get;set;}

        public Int32 Semester{get;set;}
        public Int32  GradeValue {get;set;}

        public Int32  StaffsAssigned {get;set;}

        public Int32 NumberOfTopics  {get;set;}

        public DateTime DateStarted {get;set;}

        #endregion


    }
}