using System;
namespace StudentsProgressmanagement.AllDetails
{
    public class Students_subjects
    {
        #region  Constructor
        public  Students_subjects()
        {

        }
        #endregion
        
        #region Public properties 
        // <summary>
        // Sub_stu Primary Key 
        // </summary>
        public Int32 Sub_Stu {get;set;}
       
        // <summary>
        // Subject ID Foreign Key 
        // </summary>
        public Int32  SubjectID {get;set;}
        // <summary>
        // Student ID Foreign Key 
        // </summary>
        public Int32  StudentID {get;set;}

        

        #endregion 

    }
}