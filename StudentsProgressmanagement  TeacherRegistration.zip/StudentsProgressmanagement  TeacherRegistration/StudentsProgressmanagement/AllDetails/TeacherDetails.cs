using System;

namespace StudentsProgressmanagement.AllDetails
{
    public class TeacherDetails
    {
        #region  Constructor
        public TeacherDetails()
        {

        }
        #endregion

        #region  Public Properties

        // <summary>
        // Teacher ID
        // </summary>
        public Int32 TeacherID {get;set;}

        // <summary>
        //Teacher Name
        // </summary>
        public String TeacherName {get;set;}

         // <summary>
        // Department ID
        // </summary>
        public Int32 DepartmentID {get;set;}

         // <summary>
        // Teacher RollNumber
        // </summary>
      

        public Int32 TeacherContactNumber {get;set;}

        public String TeacherMailID { get; set; }

        public String TeacherPassword { get; set; }

        public float TeacherExperience{ get; set; }

        public String TeacherQualification{ get; set; }
        #endregion
    }
}