using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using Hubstream.Development.Platform.Utils;
using StudentsProgressmanagement.AllDetails;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace StudentsProgressmanagement.ViewDetails
{
    public sealed class ViewStudentDetails : Module, IViewStudentDetails
    {
        #region Module Dependencies
        /// <summary>
        /// Database Connection Factory
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion

        #region Configuration Dependencies
        /// <summary>
        /// Database Configuration
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion

        #region Constructor
        public ViewStudentDetails() : base(typeof(ViewStudentDetails).Name)
        { }

        #endregion

        public async Task ViewStudentDetailsAsync(int StudentID)
        {
            using (IDatabaseConnection databaseConnection = this.databaseConnectionFactory.CreateDatabaseConnection(connectionString.ConnectionString))
            {
                await databaseConnection.ConnectAsync();
                List<SqlParameter> parameter = new List<SqlParameter>();
                parameter.Add(new SqlParameter("StudentIDParam", StudentID));
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                String command = "select Student.StudentID, Student.StudentName,  Student.StudentContactNumber , Student.StudentMailID, Student.Semester,Student.RollNumber,Student.StudentAddress,Student.DateOfJoining from Student";
                DataTable dataTable = await databaseCommand.ExecuteQueryAsync(command, parameter.ToArray());
                PrintTableStudentDetails(dataTable);
            }
        }



        private void PrintTableStudentDetails(DataTable dataTable)
        {
            String s1 = "DStudent ID", s2 = "Student Name", s3 = "Semester", s4 = "Department",
            s5 = "Roll Number", s6 = "Mail ID", s7 = "Contact Number";
            ExtendedConsole.WriteLine(ConsoleColor.DarkYellow, s1.PadRight(15) + s2.PadRight(15) + s3.PadRight(15) + s4.PadRight(25) + s5.PadRight(15) + s6.PadRight(25) + s7.PadRight(15));
            Console.WriteLine();
            foreach (DataRow dataRow in dataTable.Rows)
            {
                StudentDetails studentDetails = new StudentDetails();
                DepartmentDetails departmentDetails = new DepartmentDetails();
                studentDetails.StudentID = Convert.ToInt32(dataRow["StudentID"].ToString());
                studentDetails.StudentName = dataRow["StudentName"].ToString();
                studentDetails.StudentContactNumber = Convert.ToInt32(dataRow["StudentContactNumber"].ToString());
                departmentDetails.DepartmentID = Convert.ToInt32(dataRow["Experience"].ToString());
                studentDetails.StudentMailID = dataRow["StudentMailID"].ToString();
                DisplayStudentDetails(studentDetails, departmentDetails);
                Console.WriteLine(Environment.NewLine);
            }
        }

        private void DisplayStudentDetails(StudentDetails studentDetails, DepartmentDetails departmentDetails)
        {
            Console.Write(studentDetails.StudentID.ToString().PadRight(15));
            Console.Write(studentDetails.StudentName.ToString().PadRight(15));
            Console.Write(departmentDetails.Departmentname.ToString().PadRight(15));
            Console.Write(studentDetails.StudentContactNumber.ToString().PadRight(15));
            Console.Write(studentDetails.StudentMailID.ToString().PadRight(15));
        }
    }

}