using System;
using System.Threading.Tasks;

namespace StudentsProgressmanagement.ViewDetails
{
    public interface IViewTeacherDetails
    {
         /// <summary>
        /// View Teacher Profile
        /// </summary>
        /// <param name="TeacherID"></param>
        Task ViewTeacherDetailsAsync(Int32 teacherID);


        // /// <summary>
        // /// Show Teacher list to book meeting
        // /// </summary>
        // /// <param name="specialityID"></param>
        // Task TeacherListToBookMeeting(Int32 specialityID);
    }
}