using System;
using System.Threading.Tasks;
namespace StudentsProgressmanagement.ViewDetails
{
    public interface IViewSubjectDetails
    {
         /// <summary>
        /// View Patient Profile
        /// </summary>
        /// <param name="subjectID"></param>
        Task ViewSubjectDetailsAsync(Int32 subjectID);
    }
}