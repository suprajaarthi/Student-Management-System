using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
namespace StudentsProgressmanagement
{
    [ModuleServiceProvider(typeof(IStudentLogin))]
    public sealed class TeacherLogin : Module, ITeacherLogin
    {
        #region Module Dependency
        /// <summary>
        /// Database Connection Factory
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion

        #region Configuration Dependencies
        /// <summary>
        /// Connection String Configuration
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion

        #region Constructor
        public TeacherLogin() : base(typeof(TeacherLogin).Name)
        { }

        #endregion

        #region Public Methods
        /// <summary>
        /// <see cref=""/>
        /// </summary>
        /// <param name="TeacherMailID"></param>
        /// <param name="TeacherPassword"></param>
        /// <returns>Datatable4</returns>
        public async Task<DataTable> TeacherLoginAsync(String TeacherMailID, String TeacherPassword)
        {
            using (IDatabaseConnection databaseConnection = this.databaseConnectionFactory.CreateDatabaseConnection(
                connectionString.ConnectionString))
            {
                await databaseConnection.ConnectAsync();
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                List<SqlParameter> parameter = new List<SqlParameter>();
                parameter.Add(new SqlParameter("mailIdParam", TeacherMailID));
                parameter.Add(new SqlParameter("passwordParam", TeacherPassword));
                String selectCommand = "select * from Doctor where  TeacherMailId=@mailIdParam AND TeacherPassword = HASHBYTES('SHA1',@passwordParam)";
                return await databaseCommand.ExecuteQueryAsync(selectCommand, parameter.ToArray());
            }
        }
        #endregion
    }
}
