using System;
using System.Data;
using System.Threading.Tasks;
namespace StudentsProgressmanagement
{
    #region Public Methods 
    /// <summary>
    /// <see cref="StudentLogin"/>
    /// </summary>
    public interface IStudentLogin
    {
        /// <summary>
        /// Student Login Method
        /// </summary>
        /// <param name="StudentMailID">Admin Name</param>
        /// <param name="StudentPassword">Password</param>
        Task<DataTable> StudentLoginAsync(String StudentMailID, String StudentPassword);
      
    }
    #endregion
}
