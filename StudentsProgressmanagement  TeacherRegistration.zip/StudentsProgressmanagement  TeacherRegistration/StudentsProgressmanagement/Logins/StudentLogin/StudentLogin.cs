

using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
namespace StudentsProgressmanagement
{
    [ModuleServiceProvider(typeof(IStudentLogin))]
    public sealed class StudentLogin : Module, IStudentLogin
    {
        #region Module Dependency
        /// <summary>
        /// Database Connection Factory
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion


        #region Configuration Dependencies
        /// <summary>
        /// Connection String Configuration
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion

        #region Constructor
        public StudentLogin() : base(typeof(StudentLogin).Name)
        { }

        #endregion

        #region Public Methods
        /// <summary>
        /// <see cref=""/>
        /// </summary>
        /// <param name="StudentMailID"></param>
        /// <param name="StudentPassword"></param>
        /// <returns>Datatable4</returns>
        public async Task<DataTable> StudentLoginAsync(String StudentMailID, String StudentPassword)
        {
            using (IDatabaseConnection databaseConnection = this.databaseConnectionFactory.CreateDatabaseConnection(
                connectionString.ConnectionString))
            {
                await databaseConnection.ConnectAsync();
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                List<SqlParameter> parameter = new List<SqlParameter>();
                parameter.Add(new SqlParameter("mailIdParam", StudentMailID));
                parameter.Add(new SqlParameter("passwordParam", StudentPassword));
                String selectCommand = "select * from Doctor where  StudentMailId=@mailIdParam AND StudentPassword = HASHBYTES('SHA1',@passwordParam)";
                return await databaseCommand.ExecuteQueryAsync(selectCommand, parameter.ToArray());
            }
        }
        #endregion
    }
}
