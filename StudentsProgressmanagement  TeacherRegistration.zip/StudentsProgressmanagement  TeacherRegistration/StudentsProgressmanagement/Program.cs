﻿using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Utils;
using StudentsProgressmanagement.AllDetails;
using StudentsProgressmanagement.NavigationModule;
using System;
using System.Data;
using System.Threading.Tasks;

namespace StudentsProgressmanagement
{

    class Program
    {
        /// <summary>
        /// Main method which resolves the navigation module which runs the whole application.
        /// </summary>  
        /// <param name="args">Args</param>
        //[ModuleDependency]
        //private readonly INewTeacherRegistration newTeacherRegistration = null;

        public static async Task Main(string[] args)
        {
            //AppContainer appcontainer = new AppContainer();
            //appcontainer.Run();

            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.DarkBlue, "                                                        /-/-/-/        Student Management System         /-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            Console.WriteLine("");

            //TitleDescription();
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "1. New User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "2. Existing User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "3. Contact us");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "4. Exit Application");
            Console.WriteLine();
            Console.Write("Enter any option from 1 to 4 : ");
            //Int32 option;
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option .... Please type a correct option ");
                value = Console.ReadLine();
            }

            switch (option)
            {
                case 1: await AddRegDetails(); break;
                //case 1: await AddNewTeacherDetails(); break;
                //case 1: Console.Write("Great");break;
                //case 2: await LoginPageAsync(); break;
                //case 3: await CustomerSupportDetails(); break;
                //case 4: await QuitAppAsync(); break;
                default: await MainMenuExceptionAsync(); break;


            }
        }
        public static async Task MainMenuExceptionAsync()
        {
            //Console.Clear();
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "Enter a valid value");
            ExtendedConsole.WriteLine(ConsoleColor.Magenta, "Press enter to go back");
            Console.ReadLine();
            await RegistrationPageAsync();
        }
        public static async Task AddRegDetails()
        {
            ExtendedConsole.WriteLine(ConsoleColor.DarkGreen, "1. Register as Teacher");
            ExtendedConsole.WriteLine(ConsoleColor.DarkGreen, "2. Register as Student");
            ExtendedConsole.WriteLine(ConsoleColor.DarkGreen, "3. Register as TParent");
            ExtendedConsole.WriteLine(ConsoleColor.DarkGreen, "4. Exit Application");
            
            Console.WriteLine("Press Any key to go back to Main menu");
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option .... Please type a correct option ");
                value = Console.ReadLine();
            }

            switch (option)
            {
                case 1: await AddNewTeacherDetails(); break;
                    //case 1: await AddNewTeacherDetails(); break;
                    //case 1: Console.Write("Great");break;
                    //case 2: await LoginPageAsync(); break;
                    //case 3: await CustomerSupportDetails(); break;
                    //case 4: await QuitAppAsync(); break;
                    //default: await MainMenuExceptionAsync(); break;


            }
        }
        private static async Task RegistrationPageAsync()
        {
            //Console.Clear();
            //TitleDescription();
            //RegistrationDescription();
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option !.. Please Enter a Valid Number : ");
                value = Console.ReadLine();
            }
            Console.WriteLine();
            switch (option)
            {
                //case 1: await AddNewTeacherDetails(); break;
                case 1: Console.Write("Great"); break;

                //case 2: await AddNewStudentDetails(); break;
                //case 3: await NavigationMethodAsync(); break;
                default:
                    Console.WriteLine("Invaild Option..");
                    Console.WriteLine("Please Enter the correct option.. Press Enter to Continue again. ");
                    Console.ReadLine();
                    await RegistrationPageAsync();
                    break;
            }
        }
        public static async Task AddNewTeacherDetails()
        {
            TeacherDetails teacherDetails = new TeacherDetails();
            Console.Write("Enter the Teacher's Name             : ");
            teacherDetails.TeacherName = Console.ReadLine();
            //await viewSpecialities.ViewSpecialityDetailsAsync();
            Console.Write("Enter Teacher's Department ID        : ");
            teacherDetails.DepartmentID = Int32.Parse(Console.ReadLine());
            Console.Write("Enter Teacher's Qualification        : ");
            teacherDetails.TeacherQualification = Console.ReadLine();
            Console.Write("Enter Teacher's Experience           : ");
            teacherDetails.TeacherExperience = Int32.Parse(Console.ReadLine());
            Console.Write("Enter the Teacher's Contact Number   : ");
            teacherDetails.TeacherContactNumber = Int32.Parse(Console.ReadLine());
            Console.Write("Enter the Teacher's Mail ID          : ");
            teacherDetails.TeacherMailID = Console.ReadLine();
            Console.Write("Enter Teacher  password              : ");
            teacherDetails.TeacherPassword = Console.ReadLine();
            // Implement later 
            //teacherDetails.TeacherPassword = ReadPassword();

            //await newTeacherRegistration.AddNewTeacherAsync(teacherDetails);
            Console.WriteLine(teacherDetails.TeacherName + " Added Sucessfully!!!!! ");
            Console.WriteLine("Press Any key to go back to Main menu");
            Console.ReadKey();
            //await NavigationMethodAsync();
        }

    }
}