using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using StudentsProgressmanagement.AllDetails;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace StudentsProgressmanagement
{
    public sealed class DepartmentRegistration : Module, IDepartmentRegistration
    {
        #region Module Dependency 
        /// <summary>
        /// Module Dependency
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion
        #region Configuration Dependency
        /// <summary>
        /// Configuration Dependency
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public DepartmentRegistration() : base(typeof(DepartmentRegistration).Name) { }
        /// <summary>
        /// <see cref="INewDepartmentRegistration.AddNewDepartmentAsync(DepartmentDetails departmentDetails)"/>
        /// </summary>
        public async Task AddNewDepartmentAsync(DepartmentDetails departmentDetails)
        {
            using (IDatabaseConnection databaseConnection = this.databaseConnectionFactory.CreateDatabaseConnection(this.connectionString.ConnectionString))
            {
                await databaseConnection.ConnectAsync();
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                List<SqlParameter> parameters = new List<SqlParameter>();
                //parameters.Add(new SqlParameter("SpecialityIDParam", specialityDetails.SpecialityID));
                //parameters.Add(new SqlParameter("DepartmentNameParam", DepartmentDetails));
                String InsertCommand = "Insert into Department ( DepartmentName) values (@DepartmentNameParam)";
                await databaseCommand.ExecuteNonQueryAsync(InsertCommand, parameters.ToArray());
            }
        }

       
        #endregion
    }
}