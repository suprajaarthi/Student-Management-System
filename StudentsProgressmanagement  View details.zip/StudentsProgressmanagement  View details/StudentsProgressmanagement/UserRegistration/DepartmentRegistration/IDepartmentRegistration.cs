using System.Threading.Tasks;
using StudentsProgressmanagement.AllDetails;

namespace StudentsProgressmanagement
{
    public interface IDepartmentRegistration
    {
          /// <summary>
        /// This method is used to Add new epartment
        /// </summary>
        /// <param name="departmentDetails">Department Details</param>
        /// <returns>Task</returns>
        Task AddNewDepartmentAsync(DepartmentDetails departmentDetails);
    }
}