using System;
using System.Threading.Tasks;
using StudentsProgressmanagement.AllDetails;

namespace StudentsProgressmanagement
{
    public interface INewTeacherRegistration
    {
        /// <summary>
        /// This method is used to add new teachers
        /// </summary>
        /// <param name="teacherDetails">Teacher Details</param>
        /// <returns>Task</returns>
        Task AddNewTeacherAsync(TeacherDetails teacherDetails);
    }
}