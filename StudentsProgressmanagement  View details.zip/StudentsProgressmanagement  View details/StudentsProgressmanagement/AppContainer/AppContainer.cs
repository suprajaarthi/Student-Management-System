using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Configuration;
using Hubstream.Development.Platform.Database;
using StudentsProgressmanagement.NavigationModule;
using StudentsProgressmanagement.ViewDetails;

using System;

namespace StudentsProgressmanagement
{
    public sealed class AppContainer : ApplicationContainer
    {
        #region Constructor
        ///<summary>
        ///Constructor 
        ///</summary>
        public AppContainer() : base(typeof(AppContainer).Name) { }
        #endregion

        #region Overriden Methods
        ///<summary>
        ///<see cref="AppContainer.OnPreparation"/>
        /// </summary>
        protected override void OnPreparation()
        {
            AddModule(new ConfigurationManagerFactory(true));
            AddModule(new DatabaseConnectionFactory());

            AddModule(new StudentLogin());
            AddModule(new TeacherLogin());
            AddModule(new NavigationToModule());

            AddModule(new NewStudentRegistration());
            AddModule(new NewTeacherRegistration());  

            AddModule(new ViewTeacherDetails());
            AddModule(new ViewStudentDetails());

            OnPreparation();
        }

        #endregion

        #region Overriden Methods
        /// <summary>
        /// On Pre Initialize Method
        /// </summary>
        protected override void OnPreInitialize()
        {
            StudentManagementConfiguration();
            base.OnPreInitialize();
        }
        #endregion



        #region Private Methods
        /// <summary>
        /// Student Managing Configuration
        /// </summary>
        private void StudentManagementConfiguration()
        {
            IConfigurationManagerFactory factory = Resolve<IConfigurationManagerFactory>();
            IConfigurationManager manager = factory.GetConfigurationManager();
            ConnectionStringConfiguration connectionString = new ConnectionStringConfiguration();
            manager.UpdateConfiguration(connectionString);
        }
        #endregion
    }
}