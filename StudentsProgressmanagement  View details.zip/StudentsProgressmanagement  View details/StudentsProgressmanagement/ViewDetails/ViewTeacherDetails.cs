using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using Hubstream.Development.Platform.Utils;
using StudentsProgressmanagement.AllDetails;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace StudentsProgressmanagement.ViewDetails
{
    public sealed class ViewTeacherDetails  : Module, IViewTeacherDetails
    {
         #region Module Dependencies
        /// <summary>
        /// Database Connection Factory
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion

        #region Configuration Dependencies
        /// <summary>
        /// Database Configuration
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion

        #region Constructor
        public ViewTeacherDetails() : base(typeof(ViewTeacherDetails).Name)
        { }

        #endregion

        public async Task ViewTeacherDetailsAsync(int teacherID)
        {
            using (IDatabaseConnection databaseConnection = this.databaseConnectionFactory.CreateDatabaseConnection(connectionString.ConnectionString))
            {
                DepartmentDetails departmentDetails = new DepartmentDetails();
                await databaseConnection.ConnectAsync();
                List<SqlParameter> parameter = new List<SqlParameter>();
                parameter.Add(new SqlParameter("TeacherIDParam",teacherID));
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                String command = "select Teacher.TeacherID, Teacher.TeacheName, Teacher.TeacherQualification , Teacher.TeacherExperience," +
                    " Teacher.TeacherMailID, Teacher.TeacherContactNumber from Teacher";
                DataTable dataTable = await databaseCommand.ExecuteQueryAsync(command, parameter.ToArray());
                PrintTableTeacherDetails(dataTable);
            }
        }

       

        private void PrintTableTeacherDetails(DataTable dataTable)
        {
            
            String s1 = "Teacher ID", s2 = "Teacher Name", s3 = "Department", s4 = "Teacher Qualification",
            s5 = "Teacher Experience", s6 = "Teacher Mail ID", s7 = "TeacherContact Number" , s8= "Departmentnumber";
            ExtendedConsole.WriteLine(ConsoleColor.DarkYellow, s1.PadRight(15) + s2.PadRight(15) + s3.PadRight(15) + s4.PadRight(25) + s8.PadRight(15)+  s5.PadRight(15) + s6.PadRight(25) + s7.PadRight(15));
            Console.WriteLine();
            foreach (DataRow dataRow in dataTable.Rows)
            {
                TeacherDetails teacherDetails = new TeacherDetails();
                DepartmentDetails departmentDetails = new DepartmentDetails();
                teacherDetails.TeacherID = Convert.ToInt32(dataRow["TeacherID"].ToString());
                teacherDetails.TeacherName = dataRow["TeacherName"].ToString();
                departmentDetails.Departmentname = dataRow["DepartmentName"].ToString();
                departmentDetails.DepartmentID = Convert.ToInt32(dataRow["DepartmentNumber"].ToString());
                teacherDetails.TeacherQualification = dataRow["TeacherQualification"].ToString();
                teacherDetails.TeacherExperience = Convert.ToInt32(dataRow["TeacherExperience"].ToString());
                teacherDetails.TeacherMailID = dataRow["TeacherMailID"].ToString();
                teacherDetails.TeacherContactNumber = Convert.ToInt32(dataRow["TeacherContactNumber"].ToString());
                DisplayTeacherDetails(teacherDetails, departmentDetails);
                Console.WriteLine(Environment.NewLine);
            }
        }
        /// <summary>
        /// Printing Teacher Details in the console
        /// </summary>
        /// <returns>Returns a datatable of Teacher Details for appointment booking</returns>
        private void DisplayTeacherDetails(TeacherDetails teacherDetails, DepartmentDetails departmentDetails)
        {
            Console.Write(teacherDetails.TeacherID.ToString().PadRight(15));
            Console.Write(teacherDetails.TeacherName.ToString().PadRight(15));
            Console.Write(departmentDetails.Departmentname.ToString().PadRight(15));
            Console.Write(teacherDetails.TeacherQualification.ToString().PadRight(15));
            Console.Write(teacherDetails.TeacherExperience.ToString().PadRight(15));
        }

    }
}