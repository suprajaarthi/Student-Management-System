using System.Threading.Tasks;
using System;

namespace StudentsProgressmanagement.ViewDetails
{
    public interface IViewDepartmentDetails
    {
        /// <summary>
        /// View Patient Profile
        /// </summary>
        /// <param name="DepartmentID"></param>
        Task ViewDepartmentDetailsAsync(Int32 DepartmentID);
    }
}