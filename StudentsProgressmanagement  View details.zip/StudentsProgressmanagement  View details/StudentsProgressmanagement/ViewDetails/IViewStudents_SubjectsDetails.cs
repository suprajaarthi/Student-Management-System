﻿using System;
using System.Threading.Tasks;

namespace StudentsProgressmanagement.ViewDetails
{
    public interface IViewStudents_SubjectsDetails
    {
        Task ViewStudents_SubjectsDetailsAsync(int Sub_Stu);
    }
}
