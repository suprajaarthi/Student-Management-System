using System;
using System.Threading.Tasks;
namespace StudentsProgressmanagement.ViewDetails
{
    public interface IViewStudentDetails
    {
        /// <summary>
        /// View Patient Profile
        /// </summary>
        /// <param name="studentID"></param>
        Task ViewStudentDetailsAsync(Int32 studentID);
    }
}