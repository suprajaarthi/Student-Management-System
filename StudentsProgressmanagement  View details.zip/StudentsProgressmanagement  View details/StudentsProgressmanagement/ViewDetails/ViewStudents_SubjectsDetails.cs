﻿using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using Hubstream.Development.Platform.Utils;
using StudentsProgressmanagement.AllDetails;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
namespace StudentsProgressmanagement.ViewDetails
{
    public sealed class ViewStudents_SubjectsDetails : Module, IViewStudents_SubjectsDetails
    {
        #region Module Dependencies
        /// <summary>
        /// Database Connection Factory
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion

        #region Configuration Dependencies
        /// <summary>
        /// Database Configuration
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion

        #region Constructor
        public ViewStudents_SubjectsDetails() : base(typeof(ViewStudents_SubjectsDetails).Name)
        { }

        #endregion
        public async Task ViewStudents_SubjectsDetailsAsync(int Sub_Stu)
        {
            using (IDatabaseConnection databaseConnection =
                this.databaseConnectionFactory.CreateDatabaseConnection(connectionString.ConnectionString))
            {
                await databaseConnection.ConnectAsync();
                List<SqlParameter> parameter = new List<SqlParameter>();
                parameter.Add(new SqlParameter("Students_SubjectsID", Sub_Stu));
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                String command = "select Student.StudentID, Student.StudentName,Student.StudentContactNumber "
                    +"," + " Student.StudentMailID, Student.Semester,Student.RollNumber,Student.StudentAddress," +
                    "Student.DateOfJoining from Student";
                DataTable dataTable = await databaseCommand.ExecuteQueryAsync(command, parameter.ToArray());
                PrintTableStudents_SubjectsDetails(dataTable);
            }
        }

        private void PrintTableStudents_SubjectsDetails(DataTable dataTable)
        {
            String s1 = "Sub_Stu", s2 = "Subject ID", s3 = "Student ID", s4="Department ID";
            //s5 = "Roll Number", s6 = "Mail ID", s7 = "Contact Number";
            ExtendedConsole.WriteLine(ConsoleColor.DarkYellow, s1.PadRight(15) + s2.PadRight(15) +
                s3.PadRight(15)+s4.PadRight(15));
            Console.WriteLine();
            foreach (DataRow dataRow in dataTable.Rows)
            {
                Students_subjects stu_subdetails = new Students_subjects();
                SubjectDetails subjectDetails = new SubjectDetails();
                StudentDetails studentDetails = new StudentDetails();
                DepartmentDetails departmentDetails = new DepartmentDetails();
                stu_subdetails.Sub_Stu = Convert.ToInt32(dataRow["Sub_Stu"].ToString());
                subjectDetails.SubjectID = Convert.ToInt32(dataRow["SubjectID"].ToString());
                departmentDetails.DepartmentID = Convert.ToInt32(dataRow["DepartmentID"].ToString());
                studentDetails.StudentID = Convert.ToInt32(dataRow["StudentID"].ToString());
                DisplayStudents_SubjectsDetails(studentDetails, departmentDetails,subjectDetails);
                Console.WriteLine(Environment.NewLine);
            }
        }

        private void DisplayStudents_SubjectsDetails(StudentDetails studentDetails,
            DepartmentDetails departmentDetails, SubjectDetails subjectDetails)
        {
            Console.Write(studentDetails.StudentID.ToString().PadRight(15));
            Console.Write(studentDetails.StudentID.ToString().PadRight(15));
            Console.Write(subjectDetails.SubjectID.ToString().PadRight(15));
            Console.Write(departmentDetails.DepartmentID.ToString().PadRight(15));
        }
    }
}

