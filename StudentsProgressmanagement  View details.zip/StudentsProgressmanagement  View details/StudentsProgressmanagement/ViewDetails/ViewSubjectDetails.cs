using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using Hubstream.Development.Platform.Utils;
using StudentsProgressmanagement.AllDetails;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace StudentsProgressmanagement.ViewDetails

{
    public sealed  class ViewSubjectDetails  : Module, IViewSubjectDetails
    {
        
        #region Module Dependencies
        /// <summary>
        /// Database Connection Factory
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion

        #region Configuration Dependencies
        /// <summary>
        /// Database Configuration
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion

        #region Constructor
        public ViewSubjectDetails() : base(typeof(ViewSubjectDetails).Name)
        { }

        #endregion

        public async Task ViewSubjectDetailsAsync(int SubjectID)
        {
            using (IDatabaseConnection databaseConnection = this.databaseConnectionFactory.CreateDatabaseConnection(connectionString.ConnectionString))
            {
                await databaseConnection.ConnectAsync();
                List<SqlParameter> parameter = new List<SqlParameter>();
                parameter.Add(new SqlParameter("SubjectIdParam", SubjectID));
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                String command = "select Subject.SubjectID, Subject.SubjectName,  Student.StudentContactNumber ,"+
                " Subject.GradeValue, Subject.StaffsAssigned,Subject.NumberOfTopics,Subject.DateStarted,"
                +"Subject.DepartmentID from Subjectt";
                DataTable dataTable = await databaseCommand.ExecuteQueryAsync(command, parameter.ToArray());
                PrintTableSubjectDetails(dataTable);
            }
        }
        private void PrintTableSubjectDetails(DataTable dataTable)
        {
            String s1 = "Subject ID", s2 = "Subject Name", s3 = "Semester", s4 = "Department ID ",
            s5 = "GradeValue", s6 = "StaffsAssigned", s7 = "NumberOfTopics";
            //s8 ="DateStarted";
            ExtendedConsole.WriteLine(ConsoleColor.DarkYellow, s1.PadRight(15) + s2.PadRight(15) + s3.PadRight(15) + s4.PadRight(25) + s5.PadRight(15) + s6.PadRight(25) + s7.PadRight(15));
            Console.WriteLine();
            foreach (DataRow dataRow in dataTable.Rows)
            {
                SubjectDetails subjectDetails = new SubjectDetails();
                DepartmentDetails departmentDetails = new DepartmentDetails();
                subjectDetails.SubjectID = Convert.ToInt32(dataRow["SubjectID"].ToString());
                subjectDetails.SubjectName = dataRow["SubjectName"].ToString();
                subjectDetails.Semester = Convert.ToInt32(dataRow["Semester"].ToString());
                departmentDetails.DepartmentID = Convert.ToInt32(dataRow["DepartmentID"].ToString());
                subjectDetails.GradeValue = Convert.ToInt32(dataRow["GradeValue"].ToString());
                subjectDetails.StaffsAssigned = Convert.ToInt32(dataRow["StaffsAssigned"].ToString());
                subjectDetails.NumberOfTopics = Convert.ToInt32(dataRow["Numbertopics"].ToString());
                // subjectDetails.DateStarted = Convert.ToInt32(dataRow["DateStarted"].ToString());
                DisplaySubjectDetails(subjectDetails, departmentDetails);
                Console.WriteLine(Environment.NewLine);
            }
        }

        private void DisplaySubjectDetails(SubjectDetails subjectDetails , DepartmentDetails departmentDetails)
        {
            Console.Write(subjectDetails.SubjectID.ToString().PadRight(15));
            Console.Write(subjectDetails.SubjectName.ToString().PadRight(15));
            Console.Write(departmentDetails.DepartmentID.ToString().PadRight(15));
            Console.Write(subjectDetails.Semester.ToString().PadRight(15));
            Console.Write(subjectDetails.GradeValue.ToString().PadRight(15));
            Console.Write(subjectDetails.NumberOfTopics.ToString().PadRight(15));
            Console.Write(subjectDetails.StaffsAssigned.ToString().PadRight(15));
            //cannot cnv to string
            // Console.Write(subjectDetails.DateStarted".ToString().PadRight(15));
       


        }
    }

}