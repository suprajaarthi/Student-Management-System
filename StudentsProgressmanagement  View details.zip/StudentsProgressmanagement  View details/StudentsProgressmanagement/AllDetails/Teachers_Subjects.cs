using System;
namespace StudentsProgressmanagement.AllDetails
{
    public class Teachers_Subjects
    {
        #region  Constructor
        public Teachers_Subjects()
        {

        }
        #endregion

         #region Public Properties
        // <summary>
        // Teacher_sub Primary Key 
        // </summary>
        public Int32 Teacher_Sub {get;set;}
        // <summary>
        // Teacher ID Foreign Key 
        // </summary>
        public Int32 TeacherID {get;set;}
        // <summary>
        // Subject ID Foreign Key 
        // </summary>
        public Int32  SubjectID {get;set;}

        #endregion
    }
}