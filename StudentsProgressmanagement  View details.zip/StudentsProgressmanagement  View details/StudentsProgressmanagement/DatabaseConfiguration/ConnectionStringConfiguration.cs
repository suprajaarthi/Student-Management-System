using Hubstream.Development.Platform.Configuration;
using System;
namespace StudentsProgressmanagement { 
    [Serializable]
    [ModuleConfiguration]
    class ConnectionStringConfiguration : ConfigurationBase
    {
        #region Constructor
        ///<summary>
        ///Constructor
        /// </summary>
        public ConnectionStringConfiguration() : base(typeof(ConnectionStringConfiguration).Name)
        {
            this.ConnectionString = @"Integrated Security=SSPI;Persist Security
             Info=False;Initial Catalog = StudentManagementSystem ; Data Source =.";
        }
        #endregion
        #region Public Properties
        /// <summary>
        /// Connection String
        /// </summary>
        [ModuleConfigurationProperty]
        public String ConnectionString { get; set; }
        #endregion
    }
}
