﻿using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Utils;
using StudentsProgressmanagement.AllDetails;
using StudentsProgressmanagement.NavigationModule;
using StudentsProgressmanagement.ViewDetails;
using System;
using System.Data;
using System.Threading.Tasks;

namespace StudentsProgressmanagement
{

    class Program
    {
        /// <summary>
        /// Main method which resolves the navigation module which runs the whole application.
        /// </summary>  
        /// <param name="args">Args</param>
        //[ModuleDependency]
        //private readonly INewTeacherRegistration newTeacherRegistration = null;
        [ModuleDependency]
        private static readonly ITeacherLogin teacherLogin = null;

        [ModuleDependency]
        private static readonly IViewTeacherDetails viewTeacher = null;

        [ModuleDependency]
        private static readonly IViewStudentDetails viewStudent = null;

        [ModuleDependency]
        private static readonly IViewDepartmentDetails viewDepartment = null;

        [ModuleDependency]
        private static  readonly IDepartmentRegistration newDepartmentRegistration = null;

        public static async Task Main(string[] args)
        {
            //AppContainer appcontainer = new AppContainer();
            //appcontainer.Run();

            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.DarkBlue, "                                                        /-/-/-/        Student Management System         /-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            Console.WriteLine("");

            //TitleDescription();
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "1. New User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "2. Existing User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "3. Contact us");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "4. Exit Application");
            Console.WriteLine();
            Console.Write("Enter any option from 1 to 4 : ");
            //Int32 option;
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option .... Please type a correct option ");
                value = Console.ReadLine();
            }

            switch (option)
            {
                case 1: await AddRegDetails(); break;
                case 2: await LoginPageAsync(); break;
                case 3: await CustomerSupportDetails(); break;
                case 4: await QuitAppAsync(); break;
                default: await MainMenuExceptionAsync(); break;


            }
        }
        private static  async Task QuitAppAsync()
        {
            Console.Clear();
            Console.WriteLine("Are you sure to Exit the App ? \n1. Yes, I want to Exit.\n2. No, Go back to Main Menu.");
            Int32 exitOption;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out exitOption))
            {
                Console.Write("\nInvalid Option !!!!!!! Please Enter a valid option ");
                value = Console.ReadLine();
            }
            switch (exitOption)
            {
                case 1: Environment.Exit(0); break;
                case 2: await RegistrationPageAsync(); break;
                default:
                    Console.WriteLine("Invalid Input. Please Enter a valid Input.\nPress Enter key to Continue.");
                    Console.ReadLine();
                    await QuitAppAsync();
                    break;
            }
        }
        private static async Task CustomerSupportDetails()
        {
            Console.Clear();
            ExtendedConsole.WriteLine(ConsoleColor.Green, "                                                        -----------------------------------------------------\n");
            ExtendedConsole.WriteLine(ConsoleColor.Green, "                                                                      STUDENT MANAGEMENT SYSTEM              \n");
            ExtendedConsole.WriteLine(ConsoleColor.Green, "                                                                For Enquires Please Contact 99999999999      \n");
            ExtendedConsole.WriteLine(ConsoleColor.Green, "                                                          Copyright (c) 2021 Hubstream.All Rights Reserved.  \n");
            ExtendedConsole.WriteLine(ConsoleColor.Green, "                                                        -----------------------------------------------------\n");
            Console.WriteLine("Press any key to Go back to Main Menu");
            Console.ReadLine();
            //await NavigationMethodAsync();
        }
        private static void LoginDescription()
        {
            ExtendedConsole.WriteLine(ConsoleColor.Red, " ///////////////////////////////////////");
            ExtendedConsole.WriteLine(ConsoleColor.Red, "               Login Page               ");
            ExtendedConsole.WriteLine(ConsoleColor.Red, " ///////////////////////////////////////");
            Console.WriteLine();
            ExtendedConsole.WriteLine(ConsoleColor.DarkCyan, "1. Teacher Login ");
            ExtendedConsole.WriteLine(ConsoleColor.DarkCyan, "2. Student Login ");
            ExtendedConsole.WriteLine(ConsoleColor.DarkCyan, "3. Admin Login ");
            ExtendedConsole.WriteLine(ConsoleColor.DarkCyan, "4. Back to Main Menu\n");
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "Enter any option from 1 to 4 : ");
        }
        private static  void TitleDescription()
        {
            ExtendedConsole.WriteLine(ConsoleColor.Red, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.Blue, "                                                        /-/-/-/        Student Management System         /-/-/-/");
            ExtendedConsole.WriteLine(ConsoleColor.Red, "                                                        /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            Console.WriteLine("");
        }
        private static  async Task LoginPageAsync()
        {
            Console.Clear();
            TitleDescription();
            LoginDescription();
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Input !.. Please Enter a Number from 1 to 4 : ");
                value = Console.ReadLine();
            }
            Console.WriteLine();
            switch (option)
            {
                case 1: await TeacherLoginAsyncNav(); break;
                case 2: await StudentLoginAsyncNav(); break;
                case 3: await AdminLoginAsyncNav(); break;
                //case 4: await NavigationMethodAsync(); break;
                default:
                    Console.WriteLine("Invaild Option..");
                    Console.WriteLine("Please Enter the correct option.. Press Enter to Continue again. ");
                    Console.ReadLine();
                    await LoginPageAsync();
                    break;
            }
        }
        public static async Task AdminLoginAsyncNav()
        {
            Console.Clear();
            TitleDescription();
            ExtendedConsole.Write(ConsoleColor.Green, "Enter Admin ID : ");
            String adminID = Console.ReadLine();
            ExtendedConsole.Write(ConsoleColor.Green, "Enter Password : ");
            String adminPassword = Console.ReadLine();
            if (adminID == "admin" && adminPassword == "admin")
            {
                await AdminLoginAsync();
            }
            else
            {
                Console.WriteLine("Invalid Admin login Credentials ");
                Console.WriteLine("Press 1 to try again \nPress 2 to go back to main menu\n");
                Int32 option = Int32.Parse(Console.ReadLine());
                if (option == 1)
                {
                    await AdminLoginAsyncNav();
                }
                else
                {
                    await MainMenuExceptionAsync();
                }
            }
        }
        private static void AdminDescription()
        {
            //ExtendedConsole.WriteLine(ConsoleColor.Green

            ExtendedConsole.Write(ConsoleColor.Green, "///////////////////////////////////////");
            ExtendedConsole.Write(ConsoleColor.Green, "            Welcome Admin            ");
            ExtendedConsole.Write(ConsoleColor.Green,"///////////////////////////////////////");
            Console.WriteLine();
            Console.WriteLine("1. Add Department \n ");
            Console.WriteLine("2. View All the Slots \n");
            Console.WriteLine("3. View All booked Slots \n");
            Console.WriteLine("4. View All Free Slots \n");
            Console.WriteLine("5. Go back to navigation module \n");
            Console.Write("Enter any option from 1 to 6: ");
        }
        private static async Task AdminLoginAsync()
        {
        AdminMenu:
            Console.Clear();
            TitleDescription();
            AdminDescription();
            Int32 option = Int32.Parse(Console.ReadLine());
            switch (option)
            {
                case 1: await AddNewDepartmentAsync(); break;
                //case 2: await viewTeacher.ViewTeacherDetails(); break;
                //case 3: await viewStudent.ViewStudentDetails(); break;
                //case 4: await viewDepartment.ViewDptDetails(); break;
                //case 5: await NavigationMethodAsync(); break;
                default:
                    Console.WriteLine("Invaild Option..");
                    Console.WriteLine("Please Enter the correct option.. Press Enter to Continue again. ");
                    Console.ReadLine();
                    await AdminLoginAsync();
                    break;
            }
        OperationSelection:
            Console.WriteLine("\n\nPress 1 if you want to go back to Admin Menu \nPress 2 if you want to go back to main menu");
            Int32 operation = Int32.Parse(Console.ReadLine());
            if (operation == 1)
            {
                Console.Clear();
                goto AdminMenu;
            }
            else if (operation == 2)
            {
                await MainMenuExceptionAsync();
            }
            else
            {
                Console.WriteLine("Invalid option ");
                goto OperationSelection;
            }
        }
        public  async Task AddNewDepartment()
        {
            DepartmentDetails departmentDetails = new DepartmentDetails();
            Console.Write("Enter the Speciality Name :");
            departmentDetails.Departmentname = Console.ReadLine();
            await newDepartmentRegistration.AddNewDepartmentAsync(departmentDetails);
        }
        public static async Task AddNewDepartmentAsync()
        {
            DepartmentDetails departmentDetails = new DepartmentDetails();
            Console.Write("Enter Speciality Name : ");
            departmentDetails.Departmentname = Console.ReadLine();
            //await newDepartmentRegistration.AddNewDepartmentAsync(departmentDetails);
            Console.WriteLine(departmentDetails.Departmentname + " Added Sucessfully!!! ");
            Console.WriteLine("Press Any key to go back to Main menu");
            Console.ReadKey();
            await AdminLoginAsync();
        }
        public static async Task TeacherLoginAsyncNav()
        {
            Console.Clear();
            TitleDescription();
            TeacherOptionsDescription();
            TeacherDetails teacherDetails = new TeacherDetails();
            ExtendedConsole.Write(ConsoleColor.Green, "Enter Teacher Mail ID : ");
            teacherDetails.TeacherMailID = GetEmail();
            ExtendedConsole.Write(ConsoleColor.Green, "Enter Password : ");
            teacherDetails.TeacherPassword = ReadPassword();
            DataTable resultDataTable =
            await teacherLogin.TeacherLoginAsync(teacherDetails.TeacherMailID, teacherDetails.TeacherPassword);
            DataRow row = resultDataTable.FirstRow();
            Int32 teacherID = row.ConvertToInt32("Teacher ID");
            string teacherName = row.ConvertToString("Teacher Name");
            //if (adminID == "admin" && adminPassword == "admin")
            if (teacherName=="teacher")
            {
                await TeacherPageAsync(teacherID, teacherName);
            }
            else
            {
                Console.Clear();
                Int32 option;
                Console.WriteLine("Invalid MailId or Password..\n\n");
                Console.WriteLine("1.To Try Login again");
                Console.WriteLine("2.Back to Main Menu");
                Console.Write("Enter any option from 1 to 2 : ");
                string value = Console.ReadLine();
                while (value == "" || !Int32.TryParse(value, out option))
                {
                    Console.Write("\nThis is not a number!.. Please Enter a Number from 1 to 2 : ");
                    value = Console.ReadLine();
                }
                if (option == 1) { await TeacherLoginAsyncNav(); }
                //else { await NavigationMethodAsync(); }
                else { Console.Write("Invalid login credentials"); }
            }
        }
        private static void TeacherOptionsDescription()
        {
            Console.WriteLine("///////////////////////////////////////");
            Console.WriteLine("            Welcome Teacher           ");
            Console.WriteLine("///////////////////////////////////////");
            Console.WriteLine();
            Console.WriteLine("1. View My Profile ");
            Console.WriteLine("2. Add Slots ");
            Console.WriteLine("3. View All Slots ");
            Console.WriteLine("4. View Booked Slots ");
            Console.WriteLine("5. View Free Slots ");
            Console.WriteLine("6. Back to Main Menu\n");
            Console.Write("Enter any option from 1 to 5 : ");
        }
        public static  async Task TeacherPageAsync(Int32 userId, string userName)
        {
        TeacherMenu:
            Console.Clear();
            TitleDescription();
            TeacherOptionsDescription();
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Input !.. Please Enter a Number from 1 to 6 : ");
                value = Console.ReadLine();
            }
            Console.WriteLine();
            switch (option)
            {
                case 1: await viewTeacher.ViewTeacherDetailsAsync(userId); break;
                //case 2: await AddSlot(userId); break;
                //case 3: await viewSlots.ViewSlotsOfDoctor(userId); break;
                //case 4: await viewSlots.ViewBookedSlotsOfDoctor(userId); break;
                //case 5: await viewSlots.ViewFreeSlotsOfDoctor(userId); break;
                //case 6: await NavigationMethodAsync(); break;

                default:
                    Console.WriteLine("Invaild Option..");
                    Console.WriteLine("Please Enter the correct option.. Press Enter to Continue again. ");
                    Console.ReadLine();
                    await LoginPageAsync();
                    break;
            }
        OperationSelection:
            Console.WriteLine("\n\n\nPress 1 if you want to go back to Doctor Menu \nPress 2 if you want to go back to main menu");
            Int32 operation = Int32.Parse(Console.ReadLine());
            if (operation == 1)
            {
                goto TeacherMenu;
            }
            else if (operation == 2)
            {
                //await NavigationMethodAsync();
                await MainMenuExceptionAsync();
            }
            else
            {
                Console.WriteLine("Invalid option ");
                goto OperationSelection;
            }
        }
        //Student Login

        public static async Task StudentLoginAsyncNav()
        {
            Console.Clear();
            TitleDescription();
            TeacherDetails teacherDetails = new TeacherDetails();
            ExtendedConsole.Write(ConsoleColor.Green, "Enter Student Mail ID : ");
            teacherDetails.TeacherMailID = GetEmail();
            ExtendedConsole.Write(ConsoleColor.Green, "Enter Password : ");
            teacherDetails.TeacherPassword = ReadPassword();
            DataTable resultDataTable =
            await teacherLogin.TeacherLoginAsync(teacherDetails.TeacherMailID, teacherDetails.TeacherPassword);
            DataRow row = resultDataTable.FirstRow();
            Int32 teacherID = row.ConvertToInt32("Student ID");
            string teacherName = row.ConvertToString("Student Name");
            //if (adminID == "admin" && adminPassword == "admin")
            if (teacherName == "teacher")
            {
                await StudentPageAsync(teacherID, teacherName);
            }
            else
            {
                Console.Clear();
                Int32 option;
                Console.WriteLine("Invalid MailId or Password..\n\n");
                Console.WriteLine("1.To Try Login again");
                Console.WriteLine("2.Back to Main Menu");
                Console.Write("Enter any option from 1 to 2 : ");
                string value = Console.ReadLine();
                while (value == "" || !Int32.TryParse(value, out option))
                {
                    Console.Write("\nThis is not a number!.. Please Enter a Number from 1 to 2 : ");
                    value = Console.ReadLine();
                }
                if (option == 1) { await TeacherLoginAsyncNav(); }
                //else { await NavigationMethodAsync(); }
                else { Console.Write("Invalid login credentials"); }
            }
        }
        private static void StudentOptionsDescription()
        {
            Console.WriteLine("///////////////////////////////////////");
            Console.WriteLine("            Welcome Student             ");
            Console.WriteLine("///////////////////////////////////////");
            Console.WriteLine();
            Console.WriteLine("1. View My Profile ");
            Console.WriteLine("2. Add Slots ");
            Console.WriteLine("3. View All Slots ");
            Console.WriteLine("4. View Booked Slots ");
            Console.WriteLine("5. View Free Slots ");
            Console.WriteLine("6. Back to Main Menu\n");
            Console.Write("Enter any option from 1 to 5 : ");
        }
        public static async Task StudentPageAsync(Int32 userId, string userName)
        {
        TeacherMenu:
            Console.Clear();
            TitleDescription();
            StudentOptionsDescription();
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Input !.. Please Enter a Number from 1 to 6 : ");
                value = Console.ReadLine();
            }
            Console.WriteLine();
            switch (option)
            {
                case 1: await viewStudent.ViewStudentDetailsAsync(userId); break;
                //case 2: await AddSlot(userId); break;
                //case 3: await viewSlots.ViewSlotsOfDoctor(userId); break;
                //case 4: await viewSlots.ViewBookedSlotsOfDoctor(userId); break;
                //case 5: await viewSlots.ViewFreeSlotsOfDoctor(userId); break;
                //case 6: await NavigationMethodAsync(); break;

                default:
                    Console.WriteLine("Invaild Option..");
                    Console.WriteLine("Please Enter the correct option.. Press Enter to Continue again. ");
                    Console.ReadLine();
                    await LoginPageAsync();
                    break;
            }
        OperationSelection:
            Console.WriteLine("\n\n\nPress 1 if you want to go back to Doctor Menu \nPress 2 if you want to go back to main menu");
            Int32 operation = Int32.Parse(Console.ReadLine());
            if (operation == 1)
            {
                goto TeacherMenu;
            }
            else if (operation == 2)
            {
                //await NavigationMethodAsync();
                MainMenuDescription();
            }
            else
            {
                Console.WriteLine("Invalid option ");
                goto OperationSelection;
            }
        }

        private static  void MainMenuDescription()
        {
            Console.Clear();
            TitleDescription();
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "1. New User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "2. Existing User");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "3. Contact us");
            ExtendedConsole.WriteLine(ConsoleColor.Cyan, "4. Exit Application");
            Console.WriteLine();
            Console.Write("Enter any option from 1 to 4 : ");
        }

        public static async Task MainMenuExceptionAsync()
        {
            //Console.Clear();
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "Enter a valid value");
            ExtendedConsole.WriteLine(ConsoleColor.Magenta, "Press enter to go back");
            Console.ReadLine();
            await RegistrationPageAsync();
        }
        public static async Task AddRegDetails()
        {
            //RegistrationDescription();
            ExtendedConsole.WriteLine(ConsoleColor.Green, "1. Register as Teacher");
            ExtendedConsole.WriteLine(ConsoleColor.Green, "2. Register as Student");
            ExtendedConsole.WriteLine(ConsoleColor.Green, "3. Register as Parent");
            ExtendedConsole.WriteLine(ConsoleColor.Green, "4. Exit Application");
            
            Console.WriteLine("Press Any key to go back to Main menu");
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option .... Please type a correct option ");
                value = Console.ReadLine();
            }

            switch (option)
            {
                case 1: await AddNewTeacherDetails(); break;
                case 2: await AddNewStudentDetails(); break;
                case 3: await CustomerSupportDetails(); break;
                case 4: await QuitAppAsync(); break;
                default: await MainMenuExceptionAsync(); break;


            }
        }

        private static  void RegistrationDescription()
        {
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "---------------------------------------");
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "-          Registration Page          -");
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "---------------------------------------");
            Console.WriteLine();
            ExtendedConsole.WriteLine(ConsoleColor.DarkCyan, "1. New Teacher ");
            ExtendedConsole.WriteLine(ConsoleColor.DarkCyan, "2. New Student ");
            ExtendedConsole.WriteLine(ConsoleColor.DarkCyan, "3. Back to Main Menu\n");
            ExtendedConsole.WriteLine(ConsoleColor.DarkRed, "Enter any option from 1 to 3 : ");
        }
        private static async Task RegistrationPageAsync()
        {
            //Console.Clear();
            TitleDescription();
            RegistrationDescription();
            Int32 option;
            string value = Console.ReadLine();
            while (value == "" || !Int32.TryParse(value, out option))
            {
                Console.Write("\nInvalid Option !.. Please Enter a Valid Number : ");
                value = Console.ReadLine();
            }
            Console.WriteLine();
            switch (option)
            {
                case 1: await AddNewTeacherDetails(); break;
                case 2: await AddNewStudentDetails(); break;
                //case 3: await NavigationMethodAsync(); break;
                default:
                    Console.WriteLine("Invaild Option..");
                    Console.WriteLine("Please Enter the correct option.. Press Enter to Continue again. ");
                    Console.ReadLine();
                    await RegistrationPageAsync();
                    break;
            }
        }
        //can be implemented only when reads pword & mailid from the table 

        public static async Task AddNewTeacherDetails()
        {
            TeacherDetails teacherDetails = new TeacherDetails();
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter the Teacher's Name             : ");
            //Console.Write("Enter the Teacher's Name             : ");
            teacherDetails.TeacherName = Console.ReadLine();
            //await viewSpecialities.ViewSpecialityDetailsAsync();
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter Teacher's Department ID        : ");
            teacherDetails.DepartmentID = Int32.Parse(Console.ReadLine());
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter Teacher's Qualification        : ");
            teacherDetails.TeacherQualification = Console.ReadLine();
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter Teacher's Experience           : ");
            teacherDetails.TeacherExperience = Int32.Parse(Console.ReadLine());
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter the Teacher's Contact Number   : ");
            teacherDetails.TeacherContactNumber = Int32.Parse(Console.ReadLine());
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter the Teacher's Mail ID          : ");
            teacherDetails.TeacherMailID = Console.ReadLine();
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter Teacher  password              : ");
            teacherDetails.TeacherPassword = Console.ReadLine();
        
            teacherDetails.TeacherPassword = ReadPassword();

            //await newTeacherRegistration.AddNewTeacherAsync(teacherDetails);
            Console.WriteLine(teacherDetails.TeacherName + " Added Sucessfully!!!!! ");
            Console.WriteLine("Press Any key to go back to Main menu");
            Console.ReadKey();
            //await NavigationMethodAsync();
        }
        public static async Task AddNewStudentDetails()
        {
            DepartmentDetails departmentDetails = new DepartmentDetails();
            StudentDetails studentDetails = new StudentDetails();
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter the Student's Name             : ");
            studentDetails.StudentName = Console.ReadLine();
            //await viewSpecialities.ViewSpecialityDetailsAsync();
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter Student's Department ID        : ");
            departmentDetails.DepartmentID = Int32.Parse(Console.ReadLine());

            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter the Student's Contact Number   : ");
            studentDetails.StudentContactNumber = Int32.Parse(Console.ReadLine());
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter the Student's Mail ID          : ");
            studentDetails.StudentMailID = Console.ReadLine();
            ExtendedConsole.Write(ConsoleColor.DarkYellow, "Enter Student's  password            : ");
            studentDetails.StudentPassword = Console.ReadLine();

            studentDetails.StudentPassword = ReadPassword();

            //await newTeacherRegistration.AddNewTeacherAsync(teacherDetails);
            Console.WriteLine(studentDetails.StudentName + " Added Sucessfully!!!!! ");
            Console.WriteLine("Press Any key to go back to Main menu");
            Console.ReadKey();
            //await NavigationMethodAsync();
        }

        public static String GetEmail()
        {
            String email;
            while (true)
            {
                email = Console.ReadLine();
                if (email.Contains("@") && email.Contains("."))
                {
                    return email;
                }
                else
                {
                    Console.WriteLine("Invalid Email Id.. Please Enter a Valid Email Id.");
                }
            }
        }
        public static string ReadPassword()
        {
            string password = "";

            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key != ConsoleKey.Backspace)
                {
                    Console.Write("*");
                    password += info.KeyChar;
                }
                else if (info.Key == ConsoleKey.Backspace)
                {
                    if (!string.IsNullOrEmpty(password))
                    {
                        password = password.Substring(0, password.Length - 1);
                        int pos = Console.CursorLeft;
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                        Console.Write(" ");
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                    }
                }
                info = Console.ReadKey(true);
            }
            Console.WriteLine();
            return password;
        }

        public static String GetPhoneNumber()
        {
            String phoneNumber;
            while (true)
            {
                phoneNumber = Console.ReadLine();
                if (phoneNumber.Length == 10)
                {
                    return phoneNumber;
                }
                else
                {
                    Console.WriteLine("Invalid Phone number. Please Enter a Valid Phone Number.");
                }
            }
        }


    }
}