using System;
namespace StudentsProgressmanagement.AllDetails
{
    public class SubjectDetails
    {
        #region  Constructor 
        public SubjectDetails()
        {

        }
        #endregion

        #region Public Properties 

        public Int32 SubjectID{get;set;}

        public String SubjectName{get;set;}

        public Int32 DeaprtmentID{get;set;}
        #endregion


    }
}