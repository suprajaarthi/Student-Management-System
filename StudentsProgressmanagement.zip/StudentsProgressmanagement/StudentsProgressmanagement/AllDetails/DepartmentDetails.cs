using System;
namespace StudentsProgressmanagement.AllDetails
{
    public class DepartmentDetails
    {
        #region  Constructor
        public  DepartmentDetails()
        {}
         #endregion
        
        #region Public Properties
        // <summary>
        // DepartmentDetails
        // </summary>
        public Int32 DepartmentID {get;set;}

        public String  Departmentname {get;set;}

        #endregion
   
    }  
    
}

