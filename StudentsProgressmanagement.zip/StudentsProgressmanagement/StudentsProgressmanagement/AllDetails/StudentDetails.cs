using System;

namespace StudentsProgressmanagement.AllDetails
{
    #region Constructor
    public class StudentDetails
    {
         #region Constructor
        ///<summary>
        ///Constructor
        /// </summary>
        public StudentDetails()
        {

        }
        #endregion

        #region Public Properties
       
       /// <summary>
        /// Student ID
        /// </summary>
        public Int32 StudentID { get; set; }

        /// <summary>
        /// Srudent Name 
        /// </summary>
        public String StudentName { get; set; }

        /// <summary>
        /// Roll Number
        /// </summary>
        public Int32 RollNumber { get; set; }

        /// <summary>
        // Date of Birth
        /// </summary>
        public DateTime DateOfBirth { get; set; }
        
        /// <summary>
        /// Semester
        /// </summary>

        public Int32 StudentContactNumber { get; set; } 
        public String  StudentMailID { get; set; }
        public Int32 Semester { get; set; }

        public String StudentPassword { get; set; }

        /// <summary>
        /// Date of Joining
        /// </summary>
        public  DateTime DateOfJoining{ get; set; }

        public String StudentAddress { get; set; }

        public Int32 DepartmentID { get; set; } 

        #endregion


    }
     
    #endregion

        
}