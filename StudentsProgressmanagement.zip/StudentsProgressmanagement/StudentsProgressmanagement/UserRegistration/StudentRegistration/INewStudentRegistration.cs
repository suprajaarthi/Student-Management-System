
using System;
using System.Threading.Tasks;
using StudentsProgressmanagement.AllDetails;

namespace StudentsProgressmanagement
{
    public interface INewStudentRegistration
    {
        /// <summary>
        /// This method is used to add new students
        /// </summary>
        /// <param name="studentDetails">Student Details</param>
        Task AddNewStudentAsync(StudentDetails studentDetails);
    }
}