
using Hubstream.Development.Platform;
using Hubstream.Development.Platform.Database;
using StudentsProgressmanagement.AllDetails;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace StudentsProgressmanagement
{
    [ModuleServiceProvider(typeof(INewTeacherRegistration))]
    public sealed  class NewTeacherRegistration : Module, INewTeacherRegistration
    {
        #region Module Dependencies
        /// <summary>
        /// Database Connection Factory
        /// </summary>
        [ModuleDependency]
        private readonly IDatabaseConnectionFactory databaseConnectionFactory = null;
        #endregion

        #region Configuration Dependencies
        /// <summary>
        /// Database Configuration
        /// </summary>
        [ConfigurationDependency]
        private readonly ConnectionStringConfiguration connectionString = null;
        #endregion


         #region constructor
        ///<summary>
        ///Constructor
        /// </summary>
         public NewTeacherRegistration() : base(typeof(NewTeacherRegistration).Name) { }
        #endregion

        ///<summary>
        ///<see cref="INewTeacherRegistration.AddNewTeacherAsync(TeacherDetails teacherDetails)"/>
        /// </summary>


        #region Public methods
        public async Task AddNewTeacherAsync(TeacherDetails teacherDetails)
        {
            using (IDatabaseConnection databaseConnection = this.databaseConnectionFactory.
            CreateDatabaseConnection(connectionString.ConnectionString))
            {
                await databaseConnection.ConnectAsync();
                IDatabaseCommand databaseCommand = databaseConnection.CreateCommand();
                List<SqlParameter> parameter = new List<SqlParameter>();
                //parameter.Add(new SqlParameter("TeacherIDParam", TeacherDetails.TeacherID));
                parameter.Add(new SqlParameter("TeacherNameParam", teacherDetails.TeacherName));
                parameter.Add(new SqlParameter("RollIDParam", teacherDetails.TeacherID));
                parameter.Add(new SqlParameter("ExperienceParam", teacherDetails.TeacherExperience));
                parameter.Add(new SqlParameter("QualificationParam", teacherDetails.TeacherQualification));
                parameter.Add(new SqlParameter("TeacherContactNumberParam", teacherDetails.TeacherContactNumber));
                parameter.Add(new SqlParameter("TeacherMailIDParam", teacherDetails.TeacherMailID));
                parameter.Add(new SqlParameter("TeacherPasswordParam", teacherDetails.TeacherPassword));
                parameter.Add(new SqlParameter("DepartmentIDParam", teacherDetails.DepartmentID));

                String InsertCommand = "INSERT INTO Teacher" +
                    "(TeacherID,TeacherName, DepartmentID,TeacherContactNumber, TeacherMailID,TeacherPassword ,TeacherExperience,TeacherQualification) " +
                    "VALUES (@RollIDParam,@TeacherNameParam,@DepartmentIDParam,@TeacherContactNumberParam,TeacherMailIDParam,HASHBYTES" +
                    "('SHA1', @TeacherPasswordParam),@ExperienceParam,@QualificationParam)";
                await databaseCommand.ExecuteNonQueryAsync(InsertCommand, parameter.ToArray());

            }
        }

       
        #endregion

    }
}