using System;
using System.Data;
using System.Threading.Tasks;
namespace StudentsProgressmanagement
{
    #region Public Methods 
    /// <summary>
    /// <see cref="StudentLogin"/>
    /// </summary>
    public interface IStudentLogin
    {
        /// <summary>
        /// Admin Login Method
        /// </summary>
        /// <param name="adminName">Admin Name</param>
        /// <param name="password">Password</param>
        Task<DataTable> StudentLoginAsync(String StudentMailID, String StudentPassword);
        /// <summary>
        /// Welcome Message
        /// </summary>
        /// <param name="adminName">Admin Name</param>
        //Task WelcomeMessage(String adminName);
    }
    #endregion
}
